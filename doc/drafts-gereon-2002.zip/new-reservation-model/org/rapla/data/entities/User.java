package org.rapla.data.entities;

import java.util.Iterator;


/**
 Clients (other than administrator) should only be able to access the
 user-object of the user currently logged in.
 */
public interface User extends Entity
{
  void setUsername(String username);
  
  void setPassword(String password);
  
  String getUsername();
  
  /**
   Returns all reservations related to this user.
   To add relations to reservations use Reservation.addUser().
   */
  Iterator getReservations();
  
  Person getPerson();
  
  //boolean checkPassword(String password);
}