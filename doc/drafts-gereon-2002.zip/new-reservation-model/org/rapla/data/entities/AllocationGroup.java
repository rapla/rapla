package org.rapla.data.entities;

import java.util.*;
import org.rapla.data.*;


public interface AllocationGroup extends Entity
//extends org.rapla.data.clustering.Clustering  not used by clients
{ 
  void setName(String name);
  
  
  /**
   This string is used to label allocation-blocks in views.
   If nothing is defined, the label of the reservation will be used.
   If the label of the reservation is not defined, the name of the
   reservation will be used.
   */
  void setLabel(String label);
  
  
  /**
   Sets the type of the group. May affect the clustering.
   */
  void setType(GroupType type);
  
  
  /**
   Moves the allocation into this group. It will be removed from the current
   group and cluster (if any).
   The method allocationAdded() on the clustering-strategy has to be called.
   */
  void moveAllocation(Allocation a);
  
  
  
  String getName();
  
  
  /**
   By default no label will be displayed for groups (eg. in the weekview).
   */
  String getLabel();
  
  
  String getDescription();
  
  
  /**
   Can be used to iterate through all allocations of the group
   regardless of their cluster.
   Element-type: Allocation
   */
  Iterator getAllocations();
  
  
  /**
   Useful, for example, for the GUI to display allocations according to
   their clusters.
   Element-type: AllocationCluster
   */
  Iterator getClusters();
}