package org.rapla.data.entities;



public interface Person extends Entity
{
  // still to be decided which attributes to use...
}