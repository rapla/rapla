package org.rapla.data.entities;

import org.rapla.MultiLanguageName;
import org.rapla.data.attributes.Attribute;


public interface DynamicType extends Entity, MultiLanguageName
{
  void addAttribute(Attribute a);
  
  void removeAttribute(String key);
  
  /**
   Element-type: Attribute
   */
  java.util.Iterator getAttributes();
}