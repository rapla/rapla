package org.rapla.data.entities;

import java.util.Iterator;
import org.rapla.data.*;
import org.rapla.data.clustering.AllocationCluster;


public interface Allocation extends Entity
{
  void setAppointment(Appointment a);
  void addResource(Resource r);
  void removeResource(Resource r);
  Appointment getAppointment();
  Iterator getResources();
  Reservation getReservation();
  AllocationGroup getGroup();
  AllocationCluster getCluster();
}