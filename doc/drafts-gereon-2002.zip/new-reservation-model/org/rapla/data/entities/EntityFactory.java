package org.rapla.data.entities;


/**
 This interface is used to create new entities.
 In a client-server-environment there would be two
 different instances.
 Notes:
 Clients arent able to create clusters.
 There may be attributes to be initialized before using.
 Some entities have to be related before using, eg. Allocations:
 use AllocationGroup.moveAllocation().
 Only admistrators are allowed to create new users, persons and resources.
 */
public interface EntityFactory
{
  Resource createResource();
  User createUser();
  Person createPerson();
  Reservation createReservation();
  AllocationGroup createAllocationGroup();
  //AllocationCluster createAllocationCluster();  clusters are created through the interface "Clustering"
  Allocation createAllocation();  
}