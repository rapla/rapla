package org.rapla.data.entities;

import org.rapla.data.*;


public interface Period extends Entity
{
  void setName(String name);
  void setStart(RaplaDate start);
  void setEnd(RaplaDate end);
  String getName();
  RaplaDate getStart();
  RaplaDate getEnd();
}