package org.rapla.data.entities;
import java.util.*;
import org.rapla.*;


/**
 @deprecated
 */

public interface ResourceType extends Entity, MultiLanguageName
{
  /**
   Element-type: Attribute
   */
  Iterator getAttributes();
}
