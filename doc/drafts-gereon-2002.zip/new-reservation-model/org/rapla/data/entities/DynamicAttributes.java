package org.rapla.data.entities;

import java.util.Iterator;
import org.rapla.data.attributes.AttributeValue;



/**
 Entity-interfaces for entities with dynamic attributes should extends this interface.
 */
public interface DynamicAttributes
{
  /**
   Sets the type which determines the dynamic attributes.
   */
  void setType(DynamicType type);
  
  DynamicType getType();
  
  void setAttributeValue(String key, String value);
  
  /**
   Element-type: AttributeValue
   */
  Iterator getAttributeValues();
  
  AttributeValue getAttributeValue(String key);
}