package org.rapla.data.entities;

import java.util.*;


public interface Resource extends Entity, DynamicAttributes
{
  void setName(String name);
  
  //void setType(ResourceType t);
  
  
  /**
   Adds a relation to a person. This persons role is that of a manager,
   that means this person is responsible for managing this resource.
   This information is useful for the user, for example to ask for availability by email.
   Or an administrator may use this info to set priorities when conflicts arise.
   */
  void addManager(Person p);
   
   
  void removeManager(Person p);
  
  String getName();
  
  //ResourceType getType();
  
  /**
   Element-type: Person
   */
  Iterator getManagers();
}