package org.rapla.data.entities;

import java.util.*;


public interface Reservation extends Entity, DynamicAttributes
{
  void setName(String name);
  
  
  /**
   This string will be used in views.
   If nothing is defined, the name will be used.
   Also see the setLabel()-method of AllocationGroup.
   */
  void setLabel(String label);
  
  
  /**
   A short description can be defined. This information can be viewed
   by users in the GUI.
   */
  void setDescription(String description);
  
  
  
  /**
   Adds a user - the users of a reservation are allowed to modify it.
   */
  void addUser(User u);
  
  
  
  /**
   Sets the time-priod related to this reservation.
   */
  void setPeriod(Period p);
  
  
  
  /**
   Moves the group into this reservation.
   Only moving of new groups (not yet related to a reservation)
   is supported.
   */
  void moveGroup(AllocationGroup group);
  
  
  String getName();
  
  
  String getLabel();
  
  
  String getDescription();
  
  
  /**
   Element-type: AllocationGroup
   */
  Iterator getGroups();
 
  
  /**
   Can be used to iterate through ALL allocations of the reservation.
   Element-type: Allocation
   */
  Iterator getAllocations();
  
  
  /**
   Returns the users related to this reservation.
   Only these users are allowed to make changes.
   Element-type: User
   */
  Iterator getUsers();
  
  
  Period getPeriod();
}