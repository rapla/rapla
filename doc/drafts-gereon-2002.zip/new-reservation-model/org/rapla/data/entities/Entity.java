package org.rapla.data.entities;



public interface Entity
{
  /**
   Compares two entities and returns true if they are identical.
   Note: The entities may be identical even if the two objects (of the
   implementing classes) are different (eg. in the case of proxy-objects).
   */
  boolean isIdentical(Entity e);
}