package org.rapla.data;



/**
 For storing time-information (without date).
 */
public class RaplaDaytime implements java.io.Serializable
{
  private int hour, minute;
  
  
  
  public void setHour(int hour)
  {
    this.hour= hour;
  }
  
  
  public void setMinute(int minute)
  {
    this.minute= minute;
  }
  
  
  public int getHour()
  {
    return hour;
  }
  
  
  public int getMinute()
  {
    return minute;
  }
  
}