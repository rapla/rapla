package org.rapla.data.attributes;



/**
 Values are based on Strings. To store integer-values just transform to string (like: ""+value).
 */
public interface AttributeValue
{
  Attribute getAttribute();
  void setValue(String value);
  String getValue();
}