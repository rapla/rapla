package org.rapla.data.attributes;

import org.rapla.*;


public interface Attribute extends MultiLaguageName
{
  void setKey(String key);
  
  String getKey();
  
  /**
   Tests if value is a valid attribute-value.
   */
  boolean isValid(String value);
}
