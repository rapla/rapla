package org.rapla.data.attributes;



public class SelectionAttribute extends SimpleAttribute
{
  private String[] options;
  
  
  public void setOptions(String[] options)
  {
    this.options= options;
  }
  
  
  public String[] getOptions()
  {
    return options;
  }
  
  
  public boolean isValid(String value)
  {
    for (int i=0; i<options.length; i++)
    {
      if (options[i].equals(value)) { return true; }
    }
    return false;
  }
}