package org.rapla.data.attributes;



public class IntegerAttribute
{
  public boolean isValid(String value)
  {
    try
    {
      int v= Integer.parseInt(value);
    }
    catch (NumberFormatException ex) { return false; }
    return true;
  }
}