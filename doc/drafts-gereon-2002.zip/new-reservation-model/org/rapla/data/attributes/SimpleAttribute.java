package org.rapla.data.attributes;

import java.util.*;


public class SimpleAttribute implements Attribute
{
  private String key;
  private Map locales;
  
  
  public void setKey(String key)
  {
    this.key= key;
  }
  
  
  public String getKey()
  {
    return key;
  }
  
  
  public Collection getAvailableLanguages()
  {
    return locales.keySet();
  }
  
  
  public boolean isValid(String value)
  {
    return true;
  }
  
  
  public String getName(String language)
  {
    return (String) locales.get(language); 
  }
  
}