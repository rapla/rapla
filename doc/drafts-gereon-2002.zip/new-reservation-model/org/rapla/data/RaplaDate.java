package org.rapla.data;



/**
 For storing date-information (without daytime).
 */
public class RaplaDate implements java.io.Serializable
{
  private int day;
  private int month;
  private int year;
  
  
  
  public RaplaDate() {}
  
  
  
  public void setDay(int day)
  {
    this.day= day;
  }
  
  
  
  public void setMonth(int month)
  {
    this.month= month;
  }
  
  
  
  public void setYear(int year)
  {
    this.year= year;
  }
  
  
  
  public int getDay()
  {
    return day;
  }
  
  
  
  public int getMonth()
  {
    return month;
  }
  
  
  
  public int getYear()
  {
    return year;
  }
  
}