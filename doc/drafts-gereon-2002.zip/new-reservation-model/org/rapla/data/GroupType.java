package org.rapla.data;



/**
 A group can have a specific type which for example affects the clustering.
 Every possible type is defined by a class which implements GroupType.
 Such a class could have methods to customize the group.
 */
public interface GroupType
{
}