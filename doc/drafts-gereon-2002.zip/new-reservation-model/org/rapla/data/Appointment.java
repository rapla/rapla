package org.rapla.data;

import org.rapla.data.*;



public class Appointment implements java.io.Serializable
{
  private RaplaTime start;
  private RaplaTime end;
  
  
  public void setStart(RaplaTime start)
  {
    this.start= start;
  }
  
  
  public void setEnd(RaplaTime end)
  {
    this.end= end;
  }
  
  
  public RaplaTime getStart()
  {
    return start;
  }
  
  
  public RaplaTime getEnd()
  {
    return end;
  }
  
}