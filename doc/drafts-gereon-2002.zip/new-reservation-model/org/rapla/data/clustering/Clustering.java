package org.rapla.data.clustering;

import java.util.Iterator;
import org.rapla.data.entities.*;


/**
 This interface should be implemented by serverside classes which represent
 AllocationGroup-Entities (implement the AllocationGroup interface).
 All methods except "setClusteringStrategy" will be used by the related strategy-object.
 */
public interface Clustering
{
  void setClusteringStrategy(ClusteringStrategy cs);
  
  /**
   Creates a cluster with that name.
   The cluster will be part of the object on which this method is called.
   */
  AllocationCluster createCluster(String name);
  
  /**
   Only empty clusters can be deleted because an allocation has to be
   in a cluster.
   */
  void removeCluster(AllocationCluster c);
  
  /**
   Element-type: AllocationCluster
   */
  Iterator getClusters();
  
  /**
   The allocation will be removed from its current cluster and
   is put into cluster c.
   */
  void moveAllocation(Allocation a, AllocationCluster c);
}