package org.rapla.data.clustering;

import org.rapla.data.entities.*;


/**
 Implementations of this interface represent specific strategies for the
 clustering of allocation-groups. The strategy-object will be notified about
 changes on the allocation-group through this interface.
 */
public interface ClusteringStrategy
{
  /**
   A strategy can only support one group.
   The strategy only uses the Clustering interface of the group.
   */
  void setGroup(Clustering c);
  
  
  /**
   Called when a new allocation is added to a group.
   */
  void allocationAdded(Allocation a);
  
  
  /**
   Called when any data of the allocation changed.
   */
  void allocationChanged(Allocation a);
  
  
  /**
   Called when the last alocation of a cluster is removed.
   */
  void clusterEmpty();
  
  
  /**
   All allocations of the group will be iterated for clustering.
   May create new clusters and remove old clusters.
   Note: Any references to clusters will have to be updated after calling.
   This method is usefull when loading groups from persistent storage or when
   the clustering-strategy changed.
   */
  void updateAll();
}