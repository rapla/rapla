package org.rapla.data.clustering;

import java.util.Iterator;
import org.rapla.data.entities.*;



public interface AllocationCluster
{
  String getName();
  AllocationGroup getGroup();
  
  /**
   Element-type: Allocation
   */
  Iterator getAllocations();
}