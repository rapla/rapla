package org.rapla.data;



/**
 Combination of RaplaDate and RaplaDaytime.
 Eg. useful for appointments.
*/ 
public class RaplaTime implements java.io.Serializable
{
  private RaplaDate date;
  private RaplaDaytime time;
  
  
  public RaplaTime(RaplaDate date, RaplaDaytime time)
  {
    this.date= date;
    this.time= time;
  }
  
  
  void setDate(RaplaDate date)
  {
    this.date= date;
  }
  
  
  RaplaDate getDate()
  {
    return date;
  }
  
  
  void setDaytime(RaplaDaytime time)
  {
    this.time= time;
  }
  
  
  RaplaDaytime getDaytime()
  {
    return time;
  }
}